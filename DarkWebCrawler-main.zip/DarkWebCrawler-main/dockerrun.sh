#!/bin/bash

docker build -t darkwencrawler:latest . && docker container run -d -p 80:5000 darkwebcrawler:latest
