import re
import logging
import time
import random
from urllib.parse import urlparse, urljoin
from bs4 import BeautifulSoup
import trafilatura

logger = logging.getLogger(__name__)

class Crawler:
    """
    Handles crawling of .onion sites, including link discovery and content extraction.
    """
    
    def __init__(self, tor_connector):
        """
        Initialize the crawler with a Tor connector.
        
        Args:
            tor_connector: TorConnector instance
        """
        self.tor_connector = tor_connector
        self.known_directories = [
            {
                "name": "Ahmia",
                "url": "https://ahmia.fi/search/?q={keyword}",
                "link_selector": "li.result h4 a"
            },
            {
                "name": "Torch",
                "url": "http://xmh57jrzrnw6insl.onion/4a1f6b371c/search.cgi?q={keyword}",
                "link_selector": "dt a"
            },
            {
                "name": "DarkSearch",
                "url": "https://darksearch.io/search?query={keyword}",
                "link_selector": ".search-result a.title-link"
            }
        ]
        self.visited_urls = set()
        
    def search_directories(self, keyword):
        """
        Search known directories for .onion sites matching the keyword.
        
        Args:
            keyword (str): Search keyword
            
        Returns:
            list: List of discovered .onion sites with metadata
        """
        results = []
        
        logger.debug(f"Searching directories for keyword: {keyword}")
        
        for directory in self.known_directories:
            try:
                search_url = directory["url"].format(keyword=keyword)
                logger.debug(f"Searching {directory['name']} at {search_url}")
                
                # Skip non-onion URLs if they don't have proper Tor routing
                if not search_url.endswith('.onion') and not directory["name"] in ["Ahmia", "DarkSearch"]:
                    logger.debug(f"Skipping {directory['name']} - requires direct .onion access")
                    continue
                
                response = self.tor_connector.get(search_url)
                
                if not response or response.status_code != 200:
                    logger.warning(f"Failed to search {directory['name']}: Status code {response.status_code if response else 'No response'}")
                    continue
                
                soup = BeautifulSoup(response.text, 'html.parser')
                links = soup.select(directory["link_selector"])
                
                for link in links:
                    href = link.get('href')
                    if href:
                        # Handle relative URLs
                        if not href.startswith(('http://', 'https://')):
                            parsed_url = urlparse(search_url)
                            base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
                            href = urljoin(base_url, href)
                        
                        # Only include .onion URLs
                        if '.onion' in href:
                            title = link.text.strip()
                            results.append({
                                "url": href,
                                "title": title,
                                "source": directory["name"]
                            })
                
                logger.debug(f"Found {len(results)} results from {directory['name']}")
                
                # Add random delay between directory searches
                if directory != self.known_directories[-1]:
                    delay = random.uniform(2, 5)
                    time.sleep(delay)
                    
            except Exception as e:
                logger.error(f"Error searching {directory['name']}: {str(e)}")
        
        return results
    
    def crawl_site(self, url, depth=1, extraction_type='basic'):
        """
        Crawl a site to the specified depth and extract content.
        
        Args:
            url (str): URL to crawl
            depth (int): Crawling depth
            extraction_type (str): Type of extraction to perform ('basic' or 'detailed')
            
        Returns:
            dict: Crawled data including content and discovered links
        """
        results = {
            'content': {},    # URL -> extracted content
            'links': {},      # URL -> list of outbound links
            'stats': {
                'pages_crawled': 0,
                'links_discovered': 0,
                'bytes_downloaded': 0
            }
        }
        
        self.visited_urls = set()  # Reset visited URLs
        
        logger.debug(f"Starting crawl of {url} with depth {depth}")
        
        # Start recursive crawl
        self._crawl_recursive(url, depth, results, extraction_type)
        
        return results
    
    def _crawl_recursive(self, url, depth, results, extraction_type, current_depth=0):
        """
        Recursively crawl pages to the specified depth.
        
        Args:
            url (str): URL to crawl
            depth (int): Maximum crawling depth
            results (dict): Results dictionary to update
            extraction_type (str): Type of extraction to perform
            current_depth (int): Current crawling depth
        """
        # Stop if we've reached max depth or already visited this URL
        if current_depth > depth or url in self.visited_urls:
            return
        
        # Mark URL as visited
        self.visited_urls.add(url)
        
        try:
            logger.debug(f"Crawling {url} (depth {current_depth}/{depth})")
            
            # Get the page content
            response = self.tor_connector.get(url)
            
            if not response or response.status_code != 200:
                logger.warning(f"Failed to crawl {url}: Status code {response.status_code if response else 'No response'}")
                return
            
            # Update stats
            results['stats']['pages_crawled'] += 1
            results['stats']['bytes_downloaded'] += len(response.content)
            
            # Parse the page
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Extract content based on extraction type
            content = self._extract_content(response.text, soup, extraction_type)
            results['content'][url] = content
            
            # Extract links
            links = self._extract_links(url, soup)
            results['links'][url] = links
            results['stats']['links_discovered'] += len(links)
            
            # If we're not at max depth, continue crawling
            if current_depth < depth:
                # Apply appropriate delay before crawling links
                delay = random.uniform(1, 3)
                time.sleep(delay)
                
                # Only crawl .onion links
                onion_links = [link for link in links if '.onion' in link]
                
                # Limit the number of links to crawl at each level to avoid explosion
                max_links_per_level = 5
                for link in onion_links[:max_links_per_level]:
                    if link not in self.visited_urls:
                        self._crawl_recursive(link, depth, results, extraction_type, current_depth + 1)
            
        except Exception as e:
            logger.error(f"Error crawling {url}: {str(e)}")
    
    def _extract_content(self, html, soup, extraction_type):
        """
        Extract content from a page.
        
        Args:
            html (str): Raw HTML content
            soup (BeautifulSoup): Parsed HTML
            extraction_type (str): Type of extraction to perform
            
        Returns:
            dict: Extracted content
        """
        content = {
            'title': soup.title.text if soup.title else 'No Title',
            'text': ''
        }
        
        # Basic extraction - just get the main text
        if extraction_type == 'basic':
            # Use trafilatura to extract main content
            extracted_text = trafilatura.extract(html)
            
            if extracted_text:
                content['text'] = extracted_text
            else:
                # Fallback to BeautifulSoup
                paragraphs = soup.find_all('p')
                content['text'] = ' '.join([p.text for p in paragraphs])
                
        # Detailed extraction - get structured data
        elif extraction_type == 'detailed':
            # Get metadata
            content['meta'] = {
                'description': '',
                'keywords': ''
            }
            
            # Extract meta description and keywords
            meta_desc = soup.find('meta', attrs={'name': 'description'})
            if meta_desc:
                content['meta']['description'] = meta_desc.get('content', '')
                
            meta_keywords = soup.find('meta', attrs={'name': 'keywords'})
            if meta_keywords:
                content['meta']['keywords'] = meta_keywords.get('content', '')
            
            # Extract main text using trafilatura
            extracted_text = trafilatura.extract(html)
            
            if extracted_text:
                content['text'] = extracted_text
            else:
                # Fallback to BeautifulSoup
                paragraphs = soup.find_all('p')
                content['text'] = ' '.join([p.text for p in paragraphs])
            
            # Extract form information
            forms = soup.find_all('form')
            content['forms'] = []
            
            for form in forms:
                form_data = {
                    'action': form.get('action', ''),
                    'method': form.get('method', 'get'),
                    'inputs': []
                }
                
                for input_field in form.find_all('input'):
                    input_data = {
                        'name': input_field.get('name', ''),
                        'type': input_field.get('type', 'text'),
                        'required': input_field.has_attr('required')
                    }
                    form_data['inputs'].append(input_data)
                
                content['forms'].append(form_data)
            
            # Extract images
            content['images'] = []
            for img in soup.find_all('img'):
                src = img.get('src', '')
                alt = img.get('alt', '')
                
                if src:
                    # Handle relative URLs
                    if not src.startswith(('http://', 'https://')):
                        # We don't have the base URL here, so just store the relative path
                        pass
                    
                    content['images'].append({
                        'src': src,
                        'alt': alt
                    })
            
        return content
    
    def _extract_links(self, base_url, soup):
        """
        Extract links from a page.
        
        Args:
            base_url (str): Base URL for resolving relative links
            soup (BeautifulSoup): Parsed HTML
            
        Returns:
            list: List of discovered links
        """
        links = []
        
        for a_tag in soup.find_all('a', href=True):
            href = a_tag['href']
            
            # Skip empty links, anchors, javascript, and mailto links
            if not href or href.startswith(('#', 'javascript:', 'mailto:')):
                continue
            
            # Handle relative URLs
            if not href.startswith(('http://', 'https://')):
                href = urljoin(base_url, href)
            
            # Normalize URL
            parsed_url = urlparse(href)
            normalized_url = f"{parsed_url.scheme}://{parsed_url.netloc}{parsed_url.path}"
            
            # Remove trailing slash for consistency
            if normalized_url.endswith('/'):
                normalized_url = normalized_url[:-1]
            
            links.append(normalized_url)
        
        # Remove duplicates while preserving order
        unique_links = []
        seen = set()
        
        for link in links:
            if link not in seen:
                seen.add(link)
                unique_links.append(link)
        
        return unique_links
