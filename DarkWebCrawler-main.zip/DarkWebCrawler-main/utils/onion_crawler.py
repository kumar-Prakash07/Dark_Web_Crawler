from supabase import create_client, Client
import requests
from datetime import datetime
from bs4 import BeautifulSoup
import re
import time
from typing import List

# Supabase configuration
SUPABASE_URL = "https://danpffzerwcxbtrgsqfv.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRhbnBmZnplcndjeGJ0cmdzcWZ2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDkwNTcwMTIsImV4cCI6MjA2NDYzMzAxMn0.odLTuRt9Nb2xqvyjUhZmlsx799xKf_EqMiLIVSp9-HM"
supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

TOR_PROXY = {
    "http": "socks5h://127.0.0.1:9050",
    "https": "socks5h://127.0.0.1:9050"
}

class OnionCrawler:
    def __init__(self):
        self.default_sources = [
            "https://thehiddenwiki.org/",
            "http://2jwcnprqbugvyi6ok2h2h7u26qc6j5wxm7feh3znlh2qu3h6hjld4kyd.onion/",
            "http://s4k4ceiapwwgcm3mkb6e4diqecpo7kvdnfr5gg7sph7jjppqkvwwqtyd.onion/",
        ]

    def fetch_links_by_keyword(self, keyword: str = ".*") -> List[dict]:
        """Fetch links from the database that match the given keyword pattern."""
        try:
            result = supabase.table("onion_links")\
                .select("*")\
                .eq("is_active", True)\
                .execute()
            return result.data
        except Exception as e:
            print(f"[!] Error fetching links: {e}")
            return []

    def add_link(self, url: str, description: str = "", keywords: List[str] = []):
        now = datetime.utcnow().isoformat()
        try:
            supabase.table("onion_links").upsert({
                "url": url,
                "description": description,
                "keywords": keywords,
                "is_active": True,
                "last_checked": now
            }, on_conflict="url").execute()
        except Exception as e:
            print(f"[!] Failed to insert link: {e}")

    def check_link(self, url: str, max_retries: int = 3) -> bool:
        for _ in range(max_retries):
            try:
                response = requests.get(url, proxies=TOR_PROXY, timeout=10)
                return response.status_code == 200
            except:
                time.sleep(2)
        return False

    def update_link_status(self, url: str, is_active: bool):
        """Update the status of a link."""
        try:
            result = supabase.table("onion_links")\
                .update({
                    "is_active": is_active,
                    "last_checked": datetime.utcnow().isoformat()
                })\
                .eq("url", url)\
                .execute()
            
            if not result.data:
                print(f"[!] No link found with URL: {url}")
            return True
        except Exception as e:
            print(f"[!] Error updating link status: {e}")
            return False

    def remove_dead_links(self):
        """Remove links that have been marked as inactive."""
        try:
            # First, get all inactive links in batches
            batch_size = 50  # Process 50 links at a time
            offset = 0
            total_removed = 0
            
            while True:
                # Get a batch of inactive links
                result = supabase.table("onion_links")\
                    .select("id")\
                    .eq("is_active", False)\
                    .range(offset, offset + batch_size - 1)\
                    .execute()
                
                if not result.data:
                    break
                    
                # Delete each inactive link in the batch
                for link in result.data:
                    try:
                        supabase.table("onion_links")\
                            .delete()\
                            .eq("id", link["id"])\
                            .execute()
                        total_removed += 1
                    except Exception as e:
                        print(f"[!] Error deleting link {link['id']}: {e}")
                        continue
                
                offset += batch_size
                time.sleep(1)  # Add a small delay between batches
                
            if total_removed > 0:
                print(f"[+] Successfully removed {total_removed} inactive links")
            else:
                print("[i] No inactive links to remove")
                
        except Exception as e:
            print(f"[!] Error removing dead links: {e}")
            # Log the full error for debugging
            import traceback
            print(f"[!] Full error traceback: {traceback.format_exc()}")

    def crawl_and_update(self, sources: List[str] = None, keywords: List[str] = None):
        onion_regex = re.compile(r"(https?://)?[a-z2-7]{16,56}\.onion\b", re.IGNORECASE)
        if not sources:
            sources = self.default_sources

        for source in sources:
            try:
                response = requests.get(source, proxies=TOR_PROXY, timeout=20)
                soup = BeautifulSoup(response.content, "html.parser")
                for tag in soup.find_all("a", href=True):
                    href = tag["href"]
                    match = onion_regex.search(href)
                    if match:
                        raw_url = match.group()
                        clean_url = raw_url if raw_url.startswith("http") else f"http://{raw_url}"

                        desc = tag.get_text(strip=True)
                        if not desc:
                            desc = "No description available"

                        found_keywords = keywords or []

                        self.add_link(clean_url, desc[:500], found_keywords)
            except Exception as e:
                print(f"[!] Error crawling {source}: {e}")

        # Check links
        result = supabase.table("onion_links").select("url").eq("is_active", True).execute()
        if result.data:
            for row in result.data:
                url = row["url"]
                is_active = self.check_link(url)
                self.update_link_status(url, is_active)

        self.remove_dead_links()

# Example
if __name__ == "__main__":
    crawler = OnionCrawler()
    crawler.crawl_and_update()