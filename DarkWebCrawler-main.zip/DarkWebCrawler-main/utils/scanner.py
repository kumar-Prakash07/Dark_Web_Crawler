import re
import logging
import socket
import time
import random
from bs4 import BeautifulSoup
from urllib.parse import urlparse, parse_qs, urljoin

logger = logging.getLogger(__name__)

class Scanner:
    """
    Scans .onion sites for vulnerabilities, metadata, and information about their structure.
    """
    
    def __init__(self, tor_connector):
        """
        Initialize the scanner with a Tor connector.
        
        Args:
            tor_connector: TorConnector instance
        """
        self.tor_connector = tor_connector
        
    def check_site_live(self, url):
        """
        Check if a site is live and accessible.
        
        Args:
            url (str): URL to check
            
        Returns:
            bool: True if site is live, False otherwise
        """
        try:
            logger.debug(f"Checking if site is live: {url}")
            response = self.tor_connector.get(url, timeout=15)
            
            return response is not None and response.status_code < 400
            
        except Exception as e:
            logger.error(f"Error checking if site is live: {str(e)}")
            return False
    
    def scan_site(self, url):
        """
        Perform a comprehensive scan of a site.
        
        Args:
            url (str): URL to scan
            
        Returns:
            dict: Scan results including metadata and potential vulnerabilities
        """
        result = {
            'url': url,
            'status': 'unknown',
            'metadata': {},
            'technologies': [],
            'vulnerabilities': [],
            'risk_score': 0
        }
        
        try:
            logger.debug(f"Scanning site: {url}")
            
            # Check if site is live
            response = self.tor_connector.get(url, timeout=15)
            
            if not response:
                result['status'] = 'offline'
                return result
            
            result['status'] = 'online'
            result['status_code'] = response.status_code
            
            # Extract metadata
            result['metadata'] = self._extract_metadata(response, url)
            
            # Detect technologies
            result['technologies'] = self._detect_technologies(response)
            
            # Check for vulnerabilities
            result['vulnerabilities'] = self._check_vulnerabilities(response, url)
            
            # Calculate risk score (simple metric based on vulnerabilities)
            risk_score = 0
            for vuln in result['vulnerabilities']:
                risk_score += vuln['severity']
            
            result['risk_score'] = min(10, risk_score)  # Cap at 10
            
            return result
            
        except Exception as e:
            logger.error(f"Error scanning site: {str(e)}")
            result['status'] = 'error'
            result['error'] = str(e)
            return result
    
    def _extract_metadata(self, response, url):
        """
        Extract metadata from a site response.
        
        Args:
            response: HTTP response
            url (str): URL of the site
            
        Returns:
            dict: Extracted metadata
        """
        metadata = {
            'title': 'Unknown',
            'description': '',
            'server': response.headers.get('Server', 'Unknown'),
            'headers': dict(response.headers),
            'content_type': response.headers.get('Content-Type', 'Unknown'),
            'content_length': response.headers.get('Content-Length', 'Unknown'),
            'cookies': dict(response.cookies) if hasattr(response, 'cookies') else {}
        }
        
        try:
            # Parse HTML with BeautifulSoup
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Extract title
            if soup.title:
                metadata['title'] = soup.title.text.strip()
            
            # Extract meta description
            meta_desc = soup.find('meta', attrs={'name': 'description'})
            if meta_desc:
                metadata['description'] = meta_desc.get('content', '')
            
            # Extract generator info (e.g., CMS)
            meta_generator = soup.find('meta', attrs={'name': 'generator'})
            if meta_generator:
                metadata['generator'] = meta_generator.get('content', '')
            
            # Extract links count
            metadata['links_count'] = len(soup.find_all('a', href=True))
            
            # Extract forms count
            metadata['forms_count'] = len(soup.find_all('form'))
            
            # Extract scripts count
            metadata['scripts_count'] = len(soup.find_all('script'))
            
            # Extract images count
            metadata['images_count'] = len(soup.find_all('img'))
            
        except Exception as e:
            logger.error(f"Error extracting metadata: {str(e)}")
        
        return metadata
    
    def _detect_technologies(self, response):
        """
        Detect technologies used by the site.
        
        Args:
            response: HTTP response
            
        Returns:
            list: Detected technologies
        """
        technologies = []
        
        try:
            headers = response.headers
            body = response.text
            
            # Check server header
            server = headers.get('Server', '')
            if server:
                technologies.append({'name': 'Server', 'value': server})
            
            # Check for common web frameworks/CMS from response body
            tech_signatures = {
                'WordPress': ['wp-content', 'wp-includes', 'wp-admin'],
                'Drupal': ['Drupal.settings', 'drupal.org'],
                'Joomla': ['joomla', 'Joomla!'],
                'Bootstrap': ['bootstrap.css', 'bootstrap.min.css', 'bootstrap.js'],
                'jQuery': ['jquery.js', 'jquery.min.js'],
                'React': ['react.js', 'react-dom'],
                'Vue.js': ['vue.js', 'vue.min.js'],
                'Angular': ['angular.js', 'ng-app', 'ng-controller'],
                'PHP': ['PHP/', 'X-Powered-By: PHP'],
                'ASP.NET': ['ASP.NET', 'X-AspNet-Version'],
                'nginx': ['nginx'],
                'Apache': ['Apache']
            }
            
            for tech, signatures in tech_signatures.items():
                for signature in signatures:
                    if signature in body or signature in str(headers):
                        technologies.append({'name': tech, 'confidence': 'high'})
                        break
            
            # Check for JavaScript frameworks
            js_frameworks = {
                'jQuery': r'jquery.*\.js|jquery-(\d+\.)+',
                'React': r'react.*\.js|react-dom',
                'Vue.js': r'vue.*\.js',
                'Angular': r'angular.*\.js|ng\-app',
                'Backbone.js': r'backbone.*\.js',
                'Ember.js': r'ember.*\.js'
            }
            
            for framework, pattern in js_frameworks.items():
                if re.search(pattern, body, re.IGNORECASE):
                    technologies.append({'name': framework, 'confidence': 'medium'})
            
            # Check for web servers from headers
            if 'nginx' in server.lower():
                technologies.append({'name': 'nginx', 'confidence': 'high'})
            elif 'apache' in server.lower():
                technologies.append({'name': 'Apache', 'confidence': 'high'})
            elif 'microsoft-iis' in server.lower():
                technologies.append({'name': 'Microsoft IIS', 'confidence': 'high'})
            
            # Remove duplicates
            unique_techs = []
            tech_names = set()
            
            for tech in technologies:
                if tech['name'] not in tech_names:
                    tech_names.add(tech['name'])
                    unique_techs.append(tech)
            
            return unique_techs
            
        except Exception as e:
            logger.error(f"Error detecting technologies: {str(e)}")
            return technologies
    
    def _check_vulnerabilities(self, response, url):
        """
        Check for common vulnerabilities in the site.
        
        Args:
            response: HTTP response
            url (str): URL of the site
            
        Returns:
            list: Detected vulnerabilities
        """
        vulnerabilities = []
        
        try:
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Check for potential SQL injection vulnerabilities
            forms = soup.find_all('form')
            for form in forms:
                action = form.get('action', '')
                if action:
                    # Make action URL absolute
                    action_url = urljoin(url, action)
                    
                    # Check if the form has input fields that might be vulnerable
                    text_inputs = form.find_all('input', {'type': ['text', 'search', 'hidden', None]})
                    
                    if text_inputs:
                        vulnerabilities.append({
                            'type': 'Potential SQL Injection',
                            'location': action_url,
                            'description': 'Form with text input fields that might be vulnerable to SQL injection',
                            'severity': 2  # Medium severity
                        })
            
            # Check for potential XSS vulnerabilities
            if '<script>' in response.text or 'javascript:' in response.text:
                vulnerabilities.append({
                    'type': 'Potential XSS',
                    'location': url,
                    'description': 'Page contains script tags or javascript: URLs which might be vulnerable to XSS',
                    'severity': 2  # Medium severity
                })
            
            # Check for cookies without secure flag
            for cookie_name, cookie in response.cookies.items():
                if not cookie.secure:
                    vulnerabilities.append({
                        'type': 'Insecure Cookie',
                        'location': f"Cookie: {cookie_name}",
                        'description': 'Cookie without Secure flag could be transmitted over non-HTTPS connections',
                        'severity': 1  # Low severity
                    })
            
            # Check for form submissions without CSRF protection
            for form in forms:
                csrf_tokens = form.find_all('input', {'name': re.compile('csrf|token|nonce', re.IGNORECASE)})
                
                if not csrf_tokens and form.get('method', '').lower() == 'post':
                    vulnerabilities.append({
                        'type': 'Potential CSRF',
                        'location': urljoin(url, form.get('action', '')),
                        'description': 'Form submission without apparent CSRF protection',
                        'severity': 2  # Medium severity
                    })
            
            # Check for sensitive information exposure
            sensitive_patterns = [
                r'password\s*=\s*[\'"][^\'"]+[\'"]',
                r'apikey\s*=\s*[\'"][^\'"]+[\'"]',
                r'api_key\s*=\s*[\'"][^\'"]+[\'"]',
                r'secret\s*=\s*[\'"][^\'"]+[\'"]',
                r'admin\s*=\s*[\'"][^\'"]+[\'"]'
            ]
            
            for pattern in sensitive_patterns:
                matches = re.findall(pattern, response.text, re.IGNORECASE)
                
                if matches:
                    vulnerabilities.append({
                        'type': 'Sensitive Information Exposure',
                        'location': url,
                        'description': f'Possible sensitive information in page source: {matches[0][:20]}...',
                        'severity': 3  # High severity
                    })
                    break  # Only report once even if multiple matches
            
            # Check security headers
            security_headers = {
                'X-XSS-Protection': 'Missing X-XSS-Protection header',
                'X-Content-Type-Options': 'Missing X-Content-Type-Options header',
                'Content-Security-Policy': 'Missing Content-Security-Policy header',
                'X-Frame-Options': 'Missing X-Frame-Options header'
            }
            
            for header, description in security_headers.items():
                if header not in response.headers:
                    vulnerabilities.append({
                        'type': 'Missing Security Header',
                        'location': header,
                        'description': description,
                        'severity': 1  # Low severity
                    })
            
            return vulnerabilities
            
        except Exception as e:
            logger.error(f"Error checking vulnerabilities: {str(e)}")
            return vulnerabilities
