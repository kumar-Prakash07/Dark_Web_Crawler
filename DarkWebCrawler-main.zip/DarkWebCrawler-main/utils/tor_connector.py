import logging
import os
import platform
import requests
import socket
import time
import random
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

class TorConnector:
    """
    Handles connections to the Tor network for accessing .onion sites.
    Uses SOCKS5 proxy to route traffic through Tor.
    Compatible with both Windows and Linux/macOS environments.
    Can operate in simulation mode when Tor is unavailable.
    """
    
    def __init__(self, proxy_host=None, proxy_port=None, simulation_mode=False):
        """
        Initialize the Tor connector with proxy settings.
        
        Args:
            proxy_host (str, optional): Tor proxy host (default: auto-detected based on OS)
            proxy_port (int, optional): Tor proxy port (default: 9050 for Linux/macOS, 9150 for Windows)
            simulation_mode (bool): Whether to run in simulation mode without Tor (default: False)
        """
        self.simulation_mode = simulation_mode
        
        # Auto-detect default proxy settings based on platform if not provided
        if proxy_host is None:
            self.proxy_host = '127.0.0.1'
        else:
            self.proxy_host = proxy_host
            
        if proxy_port is None:
            # Tor Browser on Windows typically uses port 9150, while Tor service on Linux uses 9050
            if platform.system() == 'Windows':
                self.proxy_port = 9150
            else:
                self.proxy_port = 905
        else:
            self.proxy_port = proxy_port
        
        # Environment variable override for proxy settings
        tor_proxy_host = os.environ.get('TOR_PROXY_HOST')
        if tor_proxy_host:
            self.proxy_host = tor_proxy_host
            
        tor_proxy_port = os.environ.get('TOR_PROXY_PORT')
        if tor_proxy_port and tor_proxy_port.isdigit():
            self.proxy_port = int(tor_proxy_port)
        
        # Additional proxy servers for rotation
        self.additional_proxies = [
            # SOCKS5 Proxies
            {'host': '127.0.0.1', 'port': 9050, 'type': 'socks5'},
            {'host': '127.0.0.1', 'port': 9052, 'type': 'socks5'},

    
        ]
        
        # Current proxy index for rotation
        self.current_proxy_index = 0
        
        # Initialize with default proxy
        self.update_proxy_settings()
        
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:95.0) Gecko/20100101 Firefox/95.0',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.1 Safari/605.1.15',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36',
            'Mozilla/5.0 (X11; Linux x86_64; rv:95.0) Gecko/20100101 Firefox/95.0'
        ]
        self.timeout = 30  # Default timeout in seconds
        
        logger.info(f"TorConnector initialized - Host: {self.proxy_host}, Port: {self.proxy_port}, Simulation mode: {self.simulation_mode}")
        
    def update_proxy_settings(self):
        """Update the proxy settings with the current proxy configuration."""
        proxy = self.additional_proxies[self.current_proxy_index]
        self.proxy_host = proxy['host']
        self.proxy_port = proxy['port']
        
        if proxy['type'] == 'socks5':
            self.proxies = {
                'http': f'socks5h://{self.proxy_host}:{self.proxy_port}',
                'https': f'socks5h://{self.proxy_host}:{self.proxy_port}'
            }
        else:
            self.proxies = {
                'http': f'http://{self.proxy_host}:{self.proxy_port}',
                'https': f'http://{self.proxy_host}:{self.proxy_port}'
            }
        
        logger.debug(f"Updated proxy settings to: {self.proxies}")

    def rotate_proxy(self):
        """Rotate to the next proxy in the list."""
        self.current_proxy_index = (self.current_proxy_index + 1) % len(self.additional_proxies)
        self.update_proxy_settings()
        logger.info(f"Rotated to proxy {self.current_proxy_index + 1}/{len(self.additional_proxies)}")
        
    def get_random_user_agent(self):
        """Return a random user agent from the list."""
        return random.choice(self.user_agents)
        
    def check_connection(self):
        """
        Check if the Tor connection is available and working.
        
        Returns:
            bool: True if connection is working, False otherwise
        """
        # If in simulation mode, we return True to simulate a working connection
        if self.simulation_mode:
            logger.info("Running in simulation mode - Tor connection check bypassed")
            return True
            
        try:
            # Try to connect to the SOCKS proxy
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            sock.connect((self.proxy_host, self.proxy_port))
            sock.close()
            
            # Try to access a test site to confirm Tor connectivity
            test_url = "https://check.torproject.org/"
            response = self.get(test_url, _bypass_simulation_check=True)
            
            if response and response.status_code == 200 and "Congratulations" in response.text:
                logger.debug("Tor connection is working properly")
                return True
            else:
                logger.warning("Connected to Tor proxy but test request failed")
                return False
                
        except Exception as e:
            logger.error(f"Failed to connect to Tor network: {str(e)}")
            return False
    
    def get(self, url, headers=None, timeout=None, retries=3, _bypass_simulation_check=False):
        """
        Send a GET request through the Tor network.
        
        Args:
            url (str): URL to request
            headers (dict, optional): HTTP headers to include
            timeout (int, optional): Request timeout in seconds
            retries (int, optional): Number of retry attempts
            _bypass_simulation_check (bool, optional): Internal parameter to bypass simulation check
            
        Returns:
            requests.Response or None: Response object or None if request failed
        """
        # Ensure URL has a scheme (http:// or https://)
        if url and not url.startswith(('http://', 'https://')):
            # Check if it's an onion URL and prefix with http://
            if '.onion' in url:
                url = f"http://{url}"
            else:
                # Default to https for non-onion URLs
                url = f"https://{url}"
            logger.info(f"Added scheme to URL: {url}")
            
        if not headers:
            headers = {'User-Agent': self.get_random_user_agent()}
            
        if not timeout:
            timeout = self.timeout
        
        # If we're in simulation mode and not specifically bypassing the simulation check
        if self.simulation_mode and not _bypass_simulation_check:
            # For .onion URLs in simulation mode, return a simulated response
            if self.is_onion_url(url):
                logger.info(f"Simulation mode: Simulating response for .onion URL: {url}")
                # Create a fake response object with minimal content
                class SimulatedResponse:
                    def __init__(self):
                        self.status_code = 200
                        self.text = "<html><body><h1>Simulated Onion Site</h1><p>This is a simulated response in testing mode.</p></body></html>"
                        self.content = self.text.encode('utf-8')
                        self.headers = {'Content-Type': 'text/html'}
                    
                    def json(self):
                        return {"status": "simulated", "message": "This is simulated data"}
                
                return SimulatedResponse()
            
            # For regular URLs, try to make the request without using the Tor proxy
            logger.info(f"Simulation mode: Sending direct request to: {url}")
            try:
                response = requests.get(
                    url,
                    headers=headers,
                    timeout=timeout
                )
                return response
            except requests.exceptions.RequestException as e:
                logger.error(f"Simulation mode request failed: {str(e)}")
                return None
        
        # Track the number of proxy rotations
        proxy_rotations = 0
        max_proxy_rotations = len(self.additional_proxies)
        
        # Standard Tor proxy request logic with proxy rotation
        for attempt in range(retries):
            try:
                # Randomize request timing to avoid detection
                if attempt > 0:
                    delay = random.uniform(2, 5)
                    logger.debug(f"Retry attempt {attempt+1}/{retries}. Waiting {delay:.2f} seconds...")
                    time.sleep(delay)
                
                logger.debug(f"Sending GET request to {url} via Tor")
                response = requests.get(
                    url,
                    proxies=self.proxies,
                    headers=headers,
                    timeout=timeout
                )
                
                # Check if we hit a captcha or honeypot
                if "captcha" in response.text.lower() or "blocked" in response.text.lower():
                    logger.warning(f"Possible captcha or blocking detected at {url}")
                    if proxy_rotations < max_proxy_rotations:
                        self.rotate_proxy()
                        proxy_rotations += 1
                        continue
                
                return response
                
            except (requests.exceptions.RequestException, requests.exceptions.Timeout) as e:
                logger.error(f"Request failed (attempt {attempt+1}/{retries}): {str(e)}")
                
                # Rotate proxy on failure if we haven't tried all proxies
                if proxy_rotations < max_proxy_rotations:
                    self.rotate_proxy()
                    proxy_rotations += 1
                    continue
                
                if attempt == retries - 1:
                    return None
        
        return None
    
    def post(self, url, data=None, json=None, headers=None, timeout=None, retries=3, _bypass_simulation_check=False):
        """
        Send a POST request through the Tor network.
        
        Args:
            url (str): URL to request
            data (dict, optional): Form data to send
            json (dict, optional): JSON data to send
            headers (dict, optional): HTTP headers to include
            timeout (int, optional): Request timeout in seconds
            retries (int, optional): Number of retry attempts
            _bypass_simulation_check (bool, optional): Internal parameter to bypass simulation check
            
        Returns:
            requests.Response or None: Response object or None if request failed
        """
        # Ensure URL has a scheme (http:// or https://)
        if url and not url.startswith(('http://', 'https://')):
            # Check if it's an onion URL and prefix with http://
            if '.onion' in url:
                url = f"http://{url}"
            else:
                # Default to https for non-onion URLs
                url = f"https://{url}"
            logger.info(f"Added scheme to URL: {url}")
            
        if not headers:
            headers = {'User-Agent': self.get_random_user_agent()}
            
        if not timeout:
            timeout = self.timeout
            
        # If we're in simulation mode and not specifically bypassing the simulation check
        if self.simulation_mode and not _bypass_simulation_check:
            # For .onion URLs in simulation mode, return a simulated response
            if self.is_onion_url(url):
                logger.info(f"Simulation mode: Simulating POST response for .onion URL: {url}")
                # Create a fake response object with minimal content
                class SimulatedResponse:
                    def __init__(self):
                        self.status_code = 200
                        self.text = '{"status": "success", "message": "Simulated POST response"}'
                        self.content = self.text.encode('utf-8')
                        self.headers = {'Content-Type': 'application/json'}
                    
                    def json(self):
                        return {"status": "success", "message": "Simulated POST response"}
                
                return SimulatedResponse()
            
            # For regular URLs, try to make the request without using the Tor proxy
            logger.info(f"Simulation mode: Sending direct POST request to: {url}")
            try:
                response = requests.post(
                    url,
                    data=data,
                    json=json,
                    headers=headers,
                    timeout=timeout
                )
                return response
            except requests.exceptions.RequestException as e:
                logger.error(f"Simulation mode POST request failed: {str(e)}")
                return None
        
        # Track the number of proxy rotations
        proxy_rotations = 0
        max_proxy_rotations = len(self.additional_proxies)
        
        # Standard Tor proxy request logic with proxy rotation
        for attempt in range(retries):
            try:
                # Randomize request timing to avoid detection
                if attempt > 0:
                    delay = random.uniform(2, 5)
                    logger.debug(f"Retry attempt {attempt+1}/{retries}. Waiting {delay:.2f} seconds...")
                    time.sleep(delay)
                
                logger.debug(f"Sending POST request to {url} via Tor")
                response = requests.post(
                    url,
                    data=data,
                    json=json,
                    proxies=self.proxies,
                    headers=headers,
                    timeout=timeout
                )
                
                # Check if we hit a captcha or honeypot
                if "captcha" in response.text.lower() or "blocked" in response.text.lower():
                    logger.warning(f"Possible captcha or blocking detected at {url}")
                    if proxy_rotations < max_proxy_rotations:
                        self.rotate_proxy()
                        proxy_rotations += 1
                        continue
                
                return response
                
            except (requests.exceptions.RequestException, requests.exceptions.Timeout) as e:
                logger.error(f"Request failed (attempt {attempt+1}/{retries}): {str(e)}")
                
                # Rotate proxy on failure if we haven't tried all proxies
                if proxy_rotations < max_proxy_rotations:
                    self.rotate_proxy()
                    proxy_rotations += 1
                    continue
                
                if attempt == retries - 1:
                    return None
        
        return None
    
    def is_onion_url(self, url):
        """
        Check if a URL is an .onion address.
        
        Args:
            url (str): URL to check
            
        Returns:
            bool: True if it's an .onion URL, False otherwise
        """
        if not url:
            return False
            
        # Check for simple case where the URL contains .onion
        if '.onion' in url.lower():
            # If the URL has no scheme, try to process it directly
            if not url.startswith(('http://', 'https://')):
                return '.onion' in url.lower()
                
        # Standard URL parsing
        try:
            parsed = urlparse(url)
            # Check both netloc and path for .onion (handles URLs without scheme properly)
            return parsed.netloc.endswith('.onion') or '.onion' in parsed.path
        except Exception as e:
            logger.error(f"Error parsing URL in is_onion_url: {str(e)}")
            # If parsing fails, do a simple string check
            return '.onion' in url.lower()
            
    def enable_simulation_mode(self):
        """
        Enable simulation mode for testing without Tor network.
        Use this when Tor is not available but you still want to test the application.
        
        Returns:
            bool: Previous simulation mode state
        """
        previous_mode = self.simulation_mode
        self.simulation_mode = True
        logger.info("Simulation mode enabled - requests will not require Tor")
        return previous_mode
        
    def disable_simulation_mode(self):
        """
        Disable simulation mode and use actual Tor network for requests.
        
        Returns:
            bool: Previous simulation mode state
        """
        previous_mode = self.simulation_mode
        self.simulation_mode = False
        logger.info("Simulation mode disabled - requests will use Tor")
        return previous_mode
