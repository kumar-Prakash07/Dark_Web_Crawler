import os
import json
import csv
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

class DataProcessor:
    """
    Processes and stores crawled data in various formats.
    """
    
    def __init__(self, storage_dir="./data"):
        """
        Initialize the data processor.
        
        Args:
            storage_dir (str): Directory to store data
        """
        self.storage_dir = storage_dir
        
        # Create storage directory if it doesn't exist
        if not os.path.exists(storage_dir):
            os.makedirs(storage_dir)
    
    def save_results(self, results, crawl_id):
        """
        Save crawl results to storage.
        
        Args:
            results (dict): Crawl results
            crawl_id (str): Unique identifier for the crawl
            
        Returns:
            bool: True if saved successfully, False otherwise
        """
        try:
            # Create crawl directory
            crawl_dir = os.path.join(self.storage_dir, crawl_id)
            if not os.path.exists(crawl_dir):
                os.makedirs(crawl_dir)
            
            # Save raw results as JSON
            results_path = os.path.join(crawl_dir, "results.json")
            with open(results_path, 'w', encoding='utf-8') as f:
                json.dump(results, f, indent=2, ensure_ascii=False)
            
            logger.debug(f"Saved results to {results_path}")
            
            # Save summary information
            self._save_summary(results, crawl_dir)
            
            return True
            
        except Exception as e:
            logger.error(f"Error saving results: {str(e)}")
            return False
    
    def _save_summary(self, results, crawl_dir):
        """
        Save summary information from crawl results.
        
        Args:
            results (dict): Crawl results
            crawl_dir (str): Directory to save summary
        """
        try:
            summary = {
                'timestamp': datetime.now().isoformat(),
                'stats': {}
            }
            
            # Add crawl stats if available
            if 'crawl_results' in results and 'stats' in results['crawl_results']:
                summary['stats'] = results['crawl_results']['stats']
            
            # Add scan results summary if available
            if 'scan_results' in results:
                scan = results['scan_results']
                summary['scan'] = {
                    'url': scan.get('url', ''),
                    'status': scan.get('status', ''),
                    'risk_score': scan.get('risk_score', 0),
                    'vulnerabilities_count': len(scan.get('vulnerabilities', [])),
                    'technologies': [tech['name'] for tech in scan.get('technologies', [])]
                }
            
            # Save summary
            summary_path = os.path.join(crawl_dir, "summary.json")
            with open(summary_path, 'w', encoding='utf-8') as f:
                json.dump(summary, f, indent=2)
            
            logger.debug(f"Saved summary to {summary_path}")
            
        except Exception as e:
            logger.error(f"Error saving summary: {str(e)}")
    
    def load_results(self, crawl_id):
        """
        Load crawl results from storage.
        
        Args:
            crawl_id (str): Unique identifier for the crawl
            
        Returns:
            dict: Crawl results or None if not found
        """
        try:
            results_path = os.path.join(self.storage_dir, crawl_id, "results.json")
            
            if not os.path.exists(results_path):
                logger.warning(f"Results not found for crawl_id: {crawl_id}")
                return None
            
            with open(results_path, 'r', encoding='utf-8') as f:
                results = json.load(f)
            
            return results
            
        except Exception as e:
            logger.error(f"Error loading results: {str(e)}")
            return None
    
    def export_data(self, crawl_id, format_type='json'):
        """
        Export crawl data in the specified format.
        
        Args:
            crawl_id (str): Unique identifier for the crawl
            format_type (str): Export format ('json', 'csv')
            
        Returns:
            dict: Export data and metadata or None if failed
        """
        results = self.load_results(crawl_id)
        
        if not results:
            return None
        
        try:
            export_data = {
                'crawl_id': crawl_id,
                'timestamp': datetime.now().isoformat(),
                'format': format_type,
                'data': {}
            }
            
            if format_type == 'json':
                # For JSON, we'll return the data directly
                export_data['data'] = results
                
            elif format_type == 'csv':
                # For CSV, we need to flatten the data
                csv_data = self._convert_to_csv(results)
                export_data['data'] = csv_data
            
            return export_data
            
        except Exception as e:
            logger.error(f"Error exporting data: {str(e)}")
            return None
    
    def _convert_to_csv(self, results):
        """
        Convert results to CSV format.
        
        Args:
            results (dict): Crawl results
            
        Returns:
            dict: Dictionary of CSV data keyed by data type
        """
        csv_data = {}
        
        try:
            # Convert scan results to CSV if available
            if 'scan_results' in results:
                scan = results['scan_results']
                
                # Basic scan info
                scan_rows = [{
                    'url': scan.get('url', ''),
                    'status': scan.get('status', ''),
                    'risk_score': scan.get('risk_score', 0),
                    'title': scan.get('metadata', {}).get('title', ''),
                    'server': scan.get('metadata', {}).get('server', ''),
                    'content_type': scan.get('metadata', {}).get('content_type', '')
                }]
                
                scan_csv = self._dict_list_to_csv(scan_rows)
                csv_data['scan'] = scan_csv
                
                # Vulnerabilities
                vuln_rows = []
                for vuln in scan.get('vulnerabilities', []):
                    vuln_rows.append({
                        'url': scan.get('url', ''),
                        'type': vuln.get('type', ''),
                        'location': vuln.get('location', ''),
                        'description': vuln.get('description', ''),
                        'severity': vuln.get('severity', 0)
                    })
                
                if vuln_rows:
                    vuln_csv = self._dict_list_to_csv(vuln_rows)
                    csv_data['vulnerabilities'] = vuln_csv
                
                # Technologies
                tech_rows = []
                for tech in scan.get('technologies', []):
                    tech_rows.append({
                        'url': scan.get('url', ''),
                        'name': tech.get('name', ''),
                        'confidence': tech.get('confidence', '')
                    })
                
                if tech_rows:
                    tech_csv = self._dict_list_to_csv(tech_rows)
                    csv_data['technologies'] = tech_csv
            
            # Convert crawl results to CSV if available
            if 'crawl_results' in results and 'content' in results['crawl_results']:
                content = results['crawl_results']['content']
                
                # Extract content info
                content_rows = []
                for url, data in content.items():
                    content_rows.append({
                        'url': url,
                        'title': data.get('title', ''),
                        'text_length': len(data.get('text', '')),
                        'has_forms': 'forms' in data and len(data['forms']) > 0
                    })
                
                if content_rows:
                    content_csv = self._dict_list_to_csv(content_rows)
                    csv_data['content'] = content_csv
                
                # Extract links info
                if 'links' in results['crawl_results']:
                    links = results['crawl_results']['links']
                    
                    link_rows = []
                    for source_url, target_urls in links.items():
                        for target_url in target_urls:
                            link_rows.append({
                                'source_url': source_url,
                                'target_url': target_url
                            })
                    
                    if link_rows:
                        links_csv = self._dict_list_to_csv(link_rows)
                        csv_data['links'] = links_csv
            
            return csv_data
            
        except Exception as e:
            logger.error(f"Error converting to CSV: {str(e)}")
            return csv_data
    
    def _dict_list_to_csv(self, dict_list):
        """
        Convert a list of dictionaries to CSV format.
        
        Args:
            dict_list (list): List of dictionaries
            
        Returns:
            str: CSV data as string
        """
        if not dict_list:
            return ""
        
        output = []
        
        # Extract field names from first dictionary
        fieldnames = list(dict_list[0].keys())
        
        # Create CSV writer
        output = []
        
        # Write header
        output.append(','.join(fieldnames))
        
        # Write rows
        for row_dict in dict_list:
            # Escape values with quotes if they contain commas
            values = []
            for field in fieldnames:
                value = str(row_dict.get(field, ''))
                if ',' in value or '"' in value:
                    value = '"' + value.replace('"', '""') + '"'
                values.append(value)
            
            output.append(','.join(values))
        
        return '\n'.join(output)
    
    def generate_graph_data(self, crawl_id):
        """
        Generate data for graph visualization.
        
        Args:
            crawl_id (str): Unique identifier for the crawl
            
        Returns:
            dict: Graph data for visualization
        """
        results = self.load_results(crawl_id)
        
        if not results or 'crawl_results' not in results or 'links' not in results['crawl_results']:
            return {'nodes': [], 'links': []}
        
        try:
            links_data = results['crawl_results']['links']
            
            # Create nodes and links for graph visualization
            nodes = []
            links = []
            node_ids = {}  # Maps URL to node ID
            node_counter = 0
            
            # Process nodes
            for url in links_data.keys():
                if url not in node_ids:
                    node_ids[url] = node_counter
                    
                    # Get metadata if available
                    title = ""
                    if 'crawl_results' in results and 'content' in results['crawl_results'] and url in results['crawl_results']['content']:
                        title = results['crawl_results']['content'][url].get('title', 'No Title')
                    
                    nodes.append({
                        'id': node_counter,
                        'url': url,
                        'title': title,
                        'group': 1
                    })
                    node_counter += 1
            
            # Process links
            for source_url, target_urls in links_data.items():
                source_id = node_ids.get(source_url)
                
                if source_id is not None:
                    for target_url in target_urls:
                        # Create node for target if it doesn't exist
                        if target_url not in node_ids:
                            node_ids[target_url] = node_counter
                            nodes.append({
                                'id': node_counter,
                                'url': target_url,
                                'title': 'Unknown',
                                'group': 2
                            })
                            node_counter += 1
                        
                        target_id = node_ids[target_url]
                        
                        links.append({
                            'source': source_id,
                            'target': target_id,
                            'value': 1
                        })
            
            return {
                'nodes': nodes,
                'links': links
            }
            
        except Exception as e:
            logger.error(f"Error generating graph data: {str(e)}")
            return {'nodes': [], 'links': []}
