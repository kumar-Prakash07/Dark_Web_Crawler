from datetime import datetime
from extensions import db

class SearchHistory(db.Model):
    """Model for storing search history"""
    id = db.Column(db.Integer, primary_key=True)
    keyword = db.Column(db.String(255), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    user_agent = db.Column(db.String(512))
    ip_address = db.Column(db.String(45))  # IPv6 can be up to 45 chars
    results_count = db.Column(db.Integer, default=0)

    # Relationships
    crawls = db.relationship('CrawlSession', backref='search', lazy=True)

    def __repr__(self):
        return f"<SearchHistory {self.id}: '{self.keyword}'>"


class CrawlSession(db.Model):
    """Model for storing crawl session information"""
    id = db.Column(db.Integer, primary_key=True)
    crawl_id = db.Column(db.String(50), unique=True, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    target_url = db.Column(db.String(512))
    depth = db.Column(db.Integer, default=1)
    extraction_type = db.Column(db.String(50), default='basic')
    completed = db.Column(db.Boolean, default=False)
    duration_seconds = db.Column(db.Float)
    pages_crawled = db.Column(db.Integer, default=0)
    links_discovered = db.Column(db.Integer, default=0)
    simulation_mode = db.Column(db.Boolean, default=False)
    
    # Foreign key relationships
    search_id = db.Column(db.Integer, db.ForeignKey('search_history.id'))
    
    # Relationships
    discovered_sites = db.relationship('DiscoveredSite', backref='crawl_session', lazy=True)
    
    def __repr__(self):
        return f"<CrawlSession {self.crawl_id}>"


class DiscoveredSite(db.Model):
    """Model for storing discovered onion sites"""
    id = db.Column(db.Integer, primary_key=True)
    url = db.Column(db.String(512), nullable=False)
    title = db.Column(db.String(512))
    description = db.Column(db.Text)
    first_discovered = db.Column(db.DateTime, default=datetime.utcnow)
    last_checked = db.Column(db.DateTime, default=datetime.utcnow)
    is_online = db.Column(db.Boolean, default=True)
    page_size_kb = db.Column(db.Float)
    content_hash = db.Column(db.String(64))  # For detecting changes
    risk_score = db.Column(db.Float)
    
    # Categories and tags (comma-separated)
    categories = db.Column(db.String(255))
    tags = db.Column(db.String(512))
    
    # Foreign key relationship
    crawl_id = db.Column(db.Integer, db.ForeignKey('crawl_session.id'))
    
    # Parent-child relationship for links
    parent_id = db.Column(db.Integer, db.ForeignKey('discovered_site.id'))
    linked_sites = db.relationship(
        'DiscoveredSite', 
        backref=db.backref('parent', remote_side=[id]),
        lazy='dynamic'
    )
    
    def __repr__(self):
        return f"<DiscoveredSite {self.url}>"


class ScanResult(db.Model):
    """Model for storing site scan results"""
    id = db.Column(db.Integer, primary_key=True)
    site_id = db.Column(db.Integer, db.ForeignKey('discovered_site.id'))
    scan_time = db.Column(db.DateTime, default=datetime.utcnow)
    technologies = db.Column(db.Text)  # JSON string of detected technologies
    server_info = db.Column(db.String(255))
    security_headers = db.Column(db.Text)  # JSON string of security headers
    vulnerabilities = db.Column(db.Text)  # JSON string of detected vulnerabilities
    screenshots = db.Column(db.Text)  # Paths to screenshots, comma-separated
    notes = db.Column(db.Text)
    
    # Relationship
    site = db.relationship('DiscoveredSite', backref='scans')
    
    def __repr__(self):
        return f"<ScanResult for site_id={self.site_id}>"


class ExtractedContent(db.Model):
    """Model for storing extracted content from sites"""
    id = db.Column(db.Integer, primary_key=True)
    site_id = db.Column(db.Integer, db.ForeignKey('discovered_site.id'))
    extraction_time = db.Column(db.DateTime, default=datetime.utcnow)
    content_type = db.Column(db.String(50))  # html, text, json, etc.
    raw_content = db.Column(db.Text)
    processed_content = db.Column(db.Text)
    extracted_emails = db.Column(db.Text)  # Comma-separated emails
    extracted_phones = db.Column(db.Text)  # Comma-separated phone numbers
    extracted_cryptocurrency = db.Column(db.Text)  # JSON of extracted crypto addresses
    
    # Relationship
    site = db.relationship('DiscoveredSite', backref='extracted_contents')
    
    def __repr__(self):
        return f"<ExtractedContent for site_id={self.site_id}>"