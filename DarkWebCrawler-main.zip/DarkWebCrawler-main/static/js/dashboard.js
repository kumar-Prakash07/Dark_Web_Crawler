/**
 * Dark Web Crawler Dashboard JavaScript
 * Handles UI interactions and dashboard functionality
 */

/**
 * Document ready function
 */
$(document).ready(function() {
    // Initialize tooltip
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });
    
    // Handle form validation
    $('#crawlForm').on('submit', function() {
        const targetUrl = $('#target_url').val();
        const searchKeyword = $('#search_keyword').val();
        
        // Require at least one input
        if (!targetUrl && !searchKeyword) {
            showAlert('Please provide either a target URL or a search keyword.', 'danger');
            return false;
        }
        
        // Show loading state
        showLoading();
        
        return true;
    });
    
    // Dark/Light mode toggle if present
    $('#darkModeToggle').on('click', function() {
        $('html').attr('data-bs-theme', function(i, val) {
            return val === 'dark' ? 'light' : 'dark';
        });
        
        // Save preference
        localStorage.setItem('darkMode', $('html').attr('data-bs-theme'));
    });
    
    // Load dark/light mode preference
    const savedTheme = localStorage.getItem('darkMode');
    if (savedTheme) {
        $('html').attr('data-bs-theme', savedTheme);
    }
    
    // Handle crawl history list if present
    $('.crawl-history-item').on('click', function() {
        const crawlId = $(this).data('crawl-id');
        location.href = '/results?crawl_id=' + crawlId;
    });
    
    // Handle example URLs if present
    $('.example-url').on('click', function() {
        const url = $(this).data('url');
        $('#target_url').val(url);
    });
});

/**
 * Show an alert message
 */
function showAlert(message, type = 'info') {
    const alertHtml = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    `;
    
    // Prepend to content container
    $('.container').prepend(alertHtml);
    
    // Auto dismiss after 5 seconds
    setTimeout(function() {
        $('.alert').alert('close');
    }, 5000);
}

/**
 * Show loading state
 */
function showLoading() {
    $('#startCrawlBtn').html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Crawling...').prop('disabled', true);
}

/**
 * Format number with commas for thousands
 */
function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

/**
 * Format date to readable string
 */
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
}

/**
 * Truncate text to specified length
 */
function truncateText(text, maxLength = 100) {
    if (!text) return '';
    return text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
}

/**
 * Convert risk score to textual representation
 */
function riskScoreToText(score) {
    if (score >= 8) return 'Critical';
    if (score >= 6) return 'High';
    if (score >= 4) return 'Medium';
    if (score >= 2) return 'Low';
    return 'Minimal';
}

/**
 * Get color for risk score
 */
function getRiskScoreColor(score) {
    if (score >= 8) return 'danger';
    if (score >= 6) return 'warning';
    if (score >= 4) return 'warning';
    if (score >= 2) return 'info';
    return 'success';
}
