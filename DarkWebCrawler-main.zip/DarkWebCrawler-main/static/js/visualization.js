/**
 * Dark Web Crawler Visualization JavaScript
 * Handles network graph visualization using D3.js
 */

// Global variables for graph control
let simulation = null;
let svg = null;
let zoom = null;

/**
 * Load and render the network graph
 * @param {string} crawlId - The crawl ID
 */
function loadNetworkGraph(crawlId) {
    // Fetch graph data from API
    fetch(`/api/graph_data?crawl_id=${crawlId}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                showGraphError(data.error);
            } else {
                renderNetworkGraph(data);
            }
        })
        .catch(error => {
            showGraphError(`Error loading graph data: ${error}`);
        });
}

/**
 * Render network graph using D3.js
 * @param {Object} graphData - The graph data
 */
function renderNetworkGraph(graphData) {
    // Clear previous graph
    d3.select("#networkGraph").html("");
    
    // Get container dimensions
    const container = document.getElementById('networkGraph');
    const width = container.clientWidth;
    const height = container.clientHeight;
    
    // Define colors
    const nodeColors = {
        1: "#3498db", // Source nodes (blue)
        2: "#2ecc71"  // Target nodes (green)
    };
    
    // Set up the SVG container
    svg = d3.select("#networkGraph")
        .append("svg")
        .attr("width", width)
        .attr("height", height);
    
    // Add zoom functionality
    zoom = d3.zoom()
        .scaleExtent([0.1, 4])
        .on("zoom", (event) => {
            g.attr("transform", event.transform);
        });
    
    svg.call(zoom);
    
    // Create a container for the graph elements
    const g = svg.append("g");
    
    // Add tooltip div
    const tooltip = d3.select("body").append("div")
        .attr("class", "d3-tooltip")
        .style("position", "absolute")
        .style("visibility", "hidden")
        .style("background-color", "rgba(0, 0, 0, 0.8)")
        .style("color", "white")
        .style("padding", "8px")
        .style("border-radius", "4px")
        .style("pointer-events", "none")
        .style("z-index", "1000");
    
    // Create the graph links
    const links = g.append("g")
        .selectAll("line")
        .data(graphData.links)
        .enter()
        .append("line")
        .attr("stroke", "#555")
        .attr("stroke-opacity", 0.6)
        .attr("stroke-width", d => Math.sqrt(d.value));
    
    // Create the graph nodes
    const nodes = g.append("g")
        .selectAll("circle")
        .data(graphData.nodes)
        .enter()
        .append("circle")
        .attr("r", 8)
        .attr("fill", d => nodeColors[d.group] || "#e74c3c")
        .attr("stroke", "#fff")
        .attr("stroke-width", 1.5)
        .on("mouseover", function(event, d) {
            // Show tooltip
            tooltip
                .style("visibility", "visible")
                .html(`
                    <strong>${d.title}</strong><br>
                    <small>${d.url}</small>
                `);
                
            // Highlight node
            d3.select(this)
                .attr("stroke", "#ff0")
                .attr("stroke-width", 3);
                
            // Highlight connected links
            links.each(function(l) {
                if (l.source.id === d.id || l.target.id === d.id) {
                    d3.select(this)
                        .attr("stroke", "#ff0")
                        .attr("stroke-width", 2);
                }
            });
        })
        .on("mousemove", function(event) {
            // Position tooltip near mouse
            tooltip
                .style("top", (event.pageY - 10) + "px")
                .style("left", (event.pageX + 10) + "px");
        })
        .on("mouseout", function() {
            // Hide tooltip
            tooltip.style("visibility", "hidden");
            
            // Reset node style
            d3.select(this)
                .attr("stroke", "#fff")
                .attr("stroke-width", 1.5);
                
            // Reset links style
            links
                .attr("stroke", "#555")
                .attr("stroke-width", d => Math.sqrt(d.value));
        })
        .call(d3.drag()
            .on("start", dragStarted)
            .on("drag", dragged)
            .on("end", dragEnded));
    
    // Add node labels
    const labels = g.append("g")
        .selectAll("text")
        .data(graphData.nodes)
        .enter()
        .append("text")
        .text(d => {
            // Extract domain from URL for shorter labels
            try {
                const url = new URL(d.url);
                return url.hostname;
            } catch (e) {
                return d.url.substring(0, 20);
            }
        })
        .attr("font-size", 8)
        .attr("dx", 10)
        .attr("dy", 3)
        .attr("fill", "#ccc");
    
    // Set up the simulation
    simulation = d3.forceSimulation(graphData.nodes)
        .force("link", d3.forceLink(graphData.links).id(d => d.id).distance(100))
        .force("charge", d3.forceManyBody().strength(-300))
        .force("center", d3.forceCenter(width / 2, height / 2))
        .force("collide", d3.forceCollide().radius(30))
        .on("tick", () => {
            // Update positions on each tick
            links
                .attr("x1", d => d.source.x)
                .attr("y1", d => d.source.y)
                .attr("x2", d => d.target.x)
                .attr("y2", d => d.target.y);
            
            nodes
                .attr("cx", d => d.x)
                .attr("cy", d => d.y);
            
            labels
                .attr("x", d => d.x)
                .attr("y", d => d.y);
        });
    
    // Set up zoom controls
    document.getElementById('zoomInBtn').addEventListener('click', () => {
        zoom.scaleBy(svg.transition().duration(750), 1.2);
    });
    
    document.getElementById('zoomOutBtn').addEventListener('click', () => {
        zoom.scaleBy(svg.transition().duration(750), 0.8);
    });
    
    document.getElementById('resetZoomBtn').addEventListener('click', () => {
        svg.transition().duration(750).call(
            zoom.transform,
            d3.zoomIdentity.translate(width / 2, height / 2).scale(0.8)
                .translate(-width / 2, -height / 2)
        );
    });
    
    // Initial zoom reset to fit graph
    svg.call(
        zoom.transform,
        d3.zoomIdentity.translate(width / 2, height / 2).scale(0.8)
            .translate(-width / 2, -height / 2)
    );
}

/**
 * Show error message in the graph container
 * @param {string} message - The error message
 */
function showGraphError(message) {
    const container = document.getElementById('networkGraph');
    container.innerHTML = `
        <div class="d-flex flex-column justify-content-center align-items-center h-100">
            <div class="text-danger mb-3">
                <i class="fas fa-exclamation-triangle fa-3x"></i>
            </div>
            <h5>Graph Visualization Error</h5>
            <p class="text-muted">${message}</p>
        </div>
    `;
}

/**
 * D3 drag started event
 */
function dragStarted(event, d) {
    if (!event.active) simulation.alphaTarget(0.3).restart();
    d.fx = d.x;
    d.fy = d.y;
}

/**
 * D3 dragged event
 */
function dragged(event, d) {
    d.fx = event.x;
    d.fy = event.y;
}

/**
 * D3 drag ended event
 */
function dragEnded(event, d) {
    if (!event.active) simulation.alphaTarget(0);
    d.fx = null;
    d.fy = null;
}
