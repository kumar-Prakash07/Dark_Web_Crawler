import os
import json
import logging
from datetime import datetime
from flask import Flask, render_template, request, jsonify, flash, session, redirect, url_for
from functools import wraps
from supabase import create_client, Client
from utils.onion_crawler import OnionCrawler
import threading
import time
import requests
import os
import math
import uuid
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Supabase configuration
SUPABASE_URL = "https://danpffzerwcxbtrgsqfv.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRhbnBmZnplcndjeGJ0cmdzcWZ2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDkwNTcwMTIsImV4cCI6MjA2NDYzMzAxMn0.odLTuRt9Nb2xqvyjUhZmlsx799xKf_EqMiLIVSp9-HM"
supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

# Import utility modules
from utils.tor_connector import TorConnector
from utils.crawler import Crawler
from utils.scanner import Scanner
from utils.data_processor import DataProcessor

# Database setup
class Base(DeclarativeBase):
    pass


db = SQLAlchemy(model_class=Base)

# Initialize Flask application
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default_secret_key_for_development")

# Configure the database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///default.db")  # fallback to SQLite

app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db.init_app(app)


# Import models after db is defined
from models import SearchHistory, CrawlSession, DiscoveredSite, ScanResult, ExtractedContent

# Initialize components with simulation mode enabled by default
# This allows the application to run without an actual Tor connection
# Use simulation_mode=False to use real Tor network when available
tor_connector = TorConnector(simulation_mode=True)
crawler = Crawler(tor_connector)
scanner = Scanner(tor_connector)
data_processor = DataProcessor()

# Create database tables if they don't exist
with app.app_context():
    try:
        db.create_all()
        logger.info("Database tables created successfully")
    except Exception as e:
        logger.error(f"Error creating database tables: {str(e)}")


# Database utility functions
def save_search_history(keyword, results_count):
    """Save search history to the database"""
    try:
        search = SearchHistory(
            keyword=keyword,
            results_count=results_count,
            user_agent=request.user_agent.string if request.user_agent else None,
            ip_address=request.remote_addr
        )
        with app.app_context():
            db.session.add(search)
            db.session.commit()
        return search.id
    except Exception as e:
        logger.error(f"Error saving search history: {str(e)}")
        return None


def save_crawl_session(crawl_id, target_url, depth, extraction_type, search_id=None):
    """Save crawl session to the database"""
    try:
        crawl_session = CrawlSession(
            crawl_id=crawl_id, 
            target_url=target_url, 
            depth=depth, 
            extraction_type=extraction_type,
            search_id=search_id,
            simulation_mode=tor_connector.simulation_mode
        )
        with app.app_context():
            db.session.add(crawl_session)
            db.session.commit()
        return True
    except Exception as e:
        logger.error(f"Error saving crawl session: {str(e)}")
        return False


def update_crawl_session(crawl_id, pages_crawled, links_discovered, duration_seconds=None, completed=True):
    """Update crawl session with results"""
    try:
        with app.app_context():
            crawl = CrawlSession.query.filter_by(crawl_id=crawl_id).first()
            if crawl:
                crawl.pages_crawled = pages_crawled
                crawl.links_discovered = links_discovered
                crawl.completed = completed
                if duration_seconds:
                    crawl.duration_seconds = duration_seconds
                db.session.commit()
                return True
    except Exception as e:
        logger.error(f"Error updating crawl session: {str(e)}")
    return False


def save_discovered_site(url, title, description, crawl_id, parent_url=None, risk_score=None, categories=None):
    """Save discovered site to the database"""
    try:
        with app.app_context():
            # Find the crawl session
            crawl = CrawlSession.query.filter_by(crawl_id=crawl_id).first()
            if not crawl:
                return False
                
            # Check if site already exists
            site = DiscoveredSite.query.filter_by(url=url).first()
            
            if site:
                # Update existing site
                site.last_checked = datetime.utcnow()
                site.is_online = True
                if title:
                    site.title = title
                if description:
                    site.description = description
                if risk_score is not None:
                    site.risk_score = risk_score
                if categories:
                    site.categories = categories
            else:
                # Create new site
                site = DiscoveredSite(
                    url=url,
                    title=title,
                    description=description,
                    crawl_id=crawl.id,
                    risk_score=risk_score,
                    categories=categories
                )
                db.session.add(site)
                
            # Handle parent relationship if specified
            if parent_url and parent_url != url:
                parent_site = DiscoveredSite.query.filter_by(url=parent_url).first()
                if parent_site:
                    site.parent_id = parent_site.id
                    
            db.session.commit()
            return True
    except Exception as e:
        logger.error(f"Error saving discovered site: {str(e)}")
    return False

# Initialize Flask application
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default_secret_key_for_development")

# Login required decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_logged_in' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if username == 'admin' and password == 'admin123':
            session['user_logged_in'] = True
            return redirect(url_for('index'))
        flash('Invalid credentials', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user_logged_in', None)
    return redirect(url_for('login'))

# Initialize components
tor_connector = TorConnector(simulation_mode=False)
web_crawler = Crawler(tor_connector)
scanner = Scanner(tor_connector)
data_processor = DataProcessor()

# Initialize the crawler
crawler = OnionCrawler()

# Background task to auto-update links
def auto_update_links():
    while True:
        print("Updating links...")
        crawler.crawl_and_update()
        time.sleep(120)  # Update every hour

# Start the background thread
update_thread = threading.Thread(target=auto_update_links, daemon=True)
update_thread.start()

@app.route("/onion_links")
@login_required
def view_links():
    """Route to view active onion links with pagination."""
    try:
        page = int(request.args.get("page", 1))
        per_page = 20

        # Get links from Supabase
        result = supabase.table("onion_links")\
            .select("*")\
            .eq("is_active", True)\
            .order("created_at", desc=True)\
            .execute()

        # Calculate pagination
        total_links = len(result.data)
        total_pages = math.ceil(total_links / per_page)

        # Get paginated slice of data
        start_idx = (page - 1) * per_page
        end_idx = start_idx + per_page
        links = result.data[start_idx:end_idx]

        return render_template(
            "onion_links.html",
            links=links,
            page=page,
            total_pages=total_pages
        )
    except Exception as e:
        logger.error(f"Error in view_links: {str(e)}")
        flash("An error occurred while fetching links", "danger")
        return render_template("onion_links.html", links=[], page=1, total_pages=1)

@app.route("/api/links")
def get_links():
    """API endpoint to fetch active links (JSON)."""
    links = crawler.fetch_links_by_keyword(".*")
    return jsonify(links)

@app.route("/api/copy", methods=["POST"])
def copy_links():
    """API endpoint to copy links to clipboard."""
    data = request.json
    links = data.get("links", [])
    return jsonify({"status": "success", "copied": links})

@app.route('/results')
def results():
    """Display crawling results"""
    try:
        # Retrieve results from session
        results_json = session.get('results', '{}')
        results = json.loads(results_json)
        
        # Get the crawl session from database
        crawl_id = session.get('crawl_id', '')
        crawl_session = None
        
        try:
            with app.app_context():
                crawl_session = CrawlSession.query.filter_by(crawl_id=crawl_id).first()
        except Exception as e:
            logger.error(f"Error fetching crawl session: {str(e)}")
        
        return render_template('results.html', 
                             results=results,
                             target_url=session.get('target_url', ''),
                             crawl_id=crawl_id,
                             search_keyword=session.get('search_keyword', ''),
                             crawl_session=crawl_session)
    except Exception as e:
        logger.error(f"Error displaying results: {str(e)}")
        flash(f"An error occurred while displaying results: {str(e)}", 'danger')
        return redirect(url_for('index'))

# Utility functions
def save_search_history(keyword, results_count):
    try:
        search_data = {
            "keyword": keyword,
            "results_count": results_count,
            "user_agent": request.user_agent.string if request.user_agent else None,
            "ip_address": request.remote_addr,
            "created_at": datetime.utcnow().isoformat()
        }
        result = supabase.table("search_history").insert(search_data).execute()
        return result.data[0]["id"] if result.data else None
    except Exception as e:
        logger.error(f"Error saving search history: {str(e)}")
        return None

def save_crawl_session(target_url, depth, extraction_type, search_id=None, simulation_mode=None):
    try:
        crawl_id = str(uuid.uuid4())
        crawl_data = {
            "crawl_id": crawl_id,
            "target_url": target_url,
            "depth": depth,
            "extraction_type": extraction_type,
            "search_id": search_id,
            "simulation_mode": simulation_mode if simulation_mode is not None else tor_connector.simulation_mode,
            "created_at": datetime.utcnow().isoformat()
        }
        supabase.table("crawl_sessions").insert(crawl_data).execute()
        return crawl_id
    except Exception as e:
        logger.error(f"Error saving crawl session: {str(e)}")
        return None

# ... existing code ...

def update_crawl_session(crawl_id, pages_crawled, links_discovered, duration_seconds=None, completed=True):
    try:
        update_data = {
            "pages_crawled": pages_crawled,
            "links_discovered": links_discovered,
            "completed": completed
        }
        if duration_seconds:
            update_data["duration_seconds"] = duration_seconds
            
        supabase.table("crawl_sessions")\
            .update(update_data)\
            .eq("crawl_id", crawl_id)\
            .execute()
        return True
    except Exception as e:
        logger.error(f"Error updating crawl session: {str(e)}")
        return False

def save_discovered_site(url, title, description, crawl_id, parent_url=None, risk_score=None, categories=None):
    try:
        site_data = {
            "url": url,
            "title": title,
            "description": description,
            "crawl_id": crawl_id,
            "parent_url": parent_url,
            "risk_score": risk_score,
            "categories": categories,
            "is_online": True,
            "last_checked": datetime.utcnow().isoformat(),
            "created_at": datetime.utcnow().isoformat()
        }
        supabase.table("discovered_sites").upsert(site_data, on_conflict="url").execute()
        return True
    except Exception as e:
        logger.error(f"Error saving discovered site: {str(e)}")
        return False

@app.route('/')
@login_required
def index():
    return render_template('index.html')

def check_onion_link(url):
    try:
        proxies = {
            'http': 'socks5h://127.0.0.1:9050', 
            'https': 'socks5h://127.0.0.1:9050'
        }
        response = requests.get(url, proxies=proxies, timeout=10)
        return response.status_code == 200
    except:
        return False

@app.route('/api/check_links', methods=['POST'])
def check_links():
    data = request.json
    links = data.get('links', [])
    results = {link: check_onion_link(link) for link in links}
    return jsonify(results)

@app.route('/api/check_tor', methods=['GET'])
def check_tor_status():
    """Check if Tor connection is available and return simulation mode status"""
    try:
        is_connected = tor_connector.check_connection()
        
        return jsonify({
            'connected': is_connected,
            'simulation_mode': tor_connector.simulation_mode,
            'proxy_host': tor_connector.proxy_host,
            'proxy_port': tor_connector.proxy_port,
            'platform': os.name,
            'message': "Running in simulation mode - Tor not required" if tor_connector.simulation_mode else 
                      ("Connected to Tor network" if is_connected else "Not connected to Tor network")
        })
    except Exception as e:
        logger.error(f"Error checking Tor connection: {str(e)}")
        return jsonify({
            'connected': False, 
            'simulation_mode': tor_connector.simulation_mode,
            'error': str(e)
        }), 500
@app.route('/api/graph_data', methods=['GET'])
def get_graph_data():
    """Get data for network graph visualization"""
    try:
        crawl_id = request.args.get('crawl_id', session.get('crawl_id'))
        
        if not crawl_id:
            return jsonify({'error': 'No crawl data available'}), 400
            
        graph_data = data_processor.generate_graph_data(crawl_id)
        
        return jsonify(graph_data)
    except Exception as e:
        logger.error(f"Error generating graph data: {str(e)}")
        return jsonify({'error': str(e)}), 500
    
@app.route('/history')
def view_history():
    """View search and crawl history"""
    try:
        search_history = []
        crawl_sessions = []
        
        with app.app_context():
            search_history = SearchHistory.query.order_by(SearchHistory.timestamp.desc()).limit(50).all()
            crawl_sessions = CrawlSession.query.order_by(CrawlSession.timestamp.desc()).limit(50).all()
            
        return render_template('history.html', 
                              search_history=search_history, 
                              crawl_sessions=crawl_sessions)
    except Exception as e:
        logger.error(f"Error displaying history: {str(e)}")
        flash(f"An error occurred while displaying history: {str(e)}", 'danger')
        return redirect(url_for('index'))

@app.route('/crawl', methods=['POST'])
def crawl():
    """Handle crawling requests"""
    try:
        data = request.form
        
        # Get form data
        target_url = data.get('target_url', '')
        crawl_depth = int(data.get('crawl_depth', 1))
        search_keyword = data.get('search_keyword', '')
        extraction_type = data.get('extraction_type', 'basic')
        
        # Validate input
        if not target_url and not search_keyword:
            flash('Please provide either a target URL or a search keyword', 'danger')
            return redirect(url_for('index'))
        
        # Set crawling session data
        crawl_id = datetime.now().strftime('%Y%m%d%H%M%S')
        session['crawl_id'] = crawl_id
        session['target_url'] = target_url
        session['crawl_depth'] = crawl_depth
        session['search_keyword'] = search_keyword
        
        # Start time for performance tracking
        start_time = datetime.now()
        
        # Start with directory search if keyword is provided
        results = {}
        search_id = None
        if search_keyword:
            logger.debug(f"Searching for .onion sites with keyword: {search_keyword}")
            directory_results = web_crawler.search_directories(search_keyword)
            results['directory_results'] = directory_results
            
            # Save search history to database
            search_id = save_search_history(search_keyword, len(directory_results) if directory_results else 0)
            
            # If target URL is not provided, use the first result
            if not target_url and directory_results:
                target_url = directory_results[0]['url']
                session['target_url'] = target_url
        
        # Proceed with crawling if target URL is available
        if target_url:
            logger.debug(f"Crawling .onion site: {target_url} with depth: {crawl_depth}")
            
            # Save crawl session to database
            save_crawl_session(crawl_id, target_url, crawl_depth, extraction_type, search_id)
            
            # Check if the site is live
            if not scanner.check_site_live(target_url):
                flash(f"The site {target_url} appears to be offline or inaccessible", 'warning')
                update_crawl_session(crawl_id, 0, 0, completed=False)
                return redirect(url_for('index'))
            
            # Scan the site
            scan_results = scanner.scan_site(target_url)
            results['scan_results'] = scan_results
            
            # Save site information to database
            site_title = scan_results.get('title', 'Unknown')
            site_description = scan_results.get('description', '')
            risk_score = scan_results.get('risk_score', 0)
            categories = ','.join(scan_results.get('categories', []))
            save_discovered_site(target_url, site_title, site_description, crawl_id, risk_score=risk_score, categories=categories)
            
            # Crawl the site
            crawl_results = web_crawler.crawl_site(target_url, crawl_depth, extraction_type)
            results['crawl_results'] = crawl_results
            
            # Calculate crawl duration
            duration = (datetime.now() - start_time).total_seconds()
            
            # Update crawl session in database
            pages_crawled = len(crawl_results.get('content', {}))
            links_discovered = sum(len(links) for links in crawl_results.get('links', {}).values())
            update_crawl_session(crawl_id, pages_crawled, links_discovered, duration)
            
            # Save linked sites to database
            for url, links in crawl_results.get('links', {}).items():
                for link_url in links:
                    # Use content from crawl results if available
                    link_content = crawl_results.get('content', {}).get(link_url, {})
                    link_title = link_content.get('title', 'Unknown')
                    link_description = link_content.get('description', '')
                    save_discovered_site(link_url, link_title, link_description, crawl_id, url)
            
            # Process and save the data to filesystem
            data_processor.save_results(results, crawl_id)
            
            # Store results in session for visualization
            session['results'] = json.dumps(results)
            
            return redirect(url_for('results'))
        else:
            flash("No valid target URL found for crawling", 'warning')
            return redirect(url_for('index'))
            
    except Exception as e:
        logger.error(f"Error during crawling: {str(e)}")
        flash(f"An error occurred: {str(e)}", 'danger')
        return redirect(url_for('index'))

@app.route('/api/export', methods=['POST'])
def export_data():
    """Export crawled data in requested format"""
    try:
        export_format = request.form.get('format', 'json')
        crawl_id = request.form.get('crawl_id', session.get('crawl_id'))
        
        if not crawl_id:
            return jsonify({'error': 'No crawl data to export'}), 400
            
        # Get the export data
        export_data = data_processor.export_data(crawl_id, export_format)
        
        return jsonify({
            'success': True,
            'data': export_data,
            'format': export_format
        })
    except Exception as e:
        logger.error(f"Error exporting data: {str(e)}")
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    try:
        # Start background thread
        update_thread = threading.Thread(target=auto_update_links, daemon=True)
        update_thread.start()
        
        # Start Flask application with reloader disabled
        app.run(
            host='0.0.0.0',
            port=5000,
            debug=False,  # Disable debug mode
            use_reloader=False  # Disable the reloader
        )
    except Exception as e:
        logger.error(f"Error starting application: {str(e)}")
        raise
        
      